# -*- coding: utf-8 -*-

import sys

sys.stdout.write('importing pkg1.sub2\n')
